Thanks for downloading this theme!

Theme Name: Mentor
Theme URL: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com